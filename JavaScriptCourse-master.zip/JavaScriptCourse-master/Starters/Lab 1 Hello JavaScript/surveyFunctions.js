document.addEventListener("DOMContentLoaded", function () {
  // Add your JavaScript here
  alert('ready!');
});
