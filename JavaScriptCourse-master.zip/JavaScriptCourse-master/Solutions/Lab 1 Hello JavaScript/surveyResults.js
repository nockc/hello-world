var raw_survey_results = [
  {
    "Day": 1,
    "excellent": 20,
    "good": 25,
    "okay": 35,
    "poor": 15,
    "terrible": 5
  },
  {
    "Day": 2,
    "excellent": 22,
    "good": 22,
    "okay": 36,
    "poor": 16,
    "terrible": 4
  },
  {
    "Day": 3,
    "excellent": 24,
    "good": 26,
    "okay": 35,
    "poor": 15,
    "terrible": 5
  },
  {
    "Day": 4,
    "excellent": 21,
    "good": 27,
    "okay": 34,
    "poor": 14,
    "terrible": 4
  },
  {
    "Day": 5,
    "excellent": 23,
    "good": 27,
    "okay": 32,
    "poor": 15,
    "terrible": 3
  },
  {
    "Day": 6,
    "excellent": 24,
    "good": 30,
    "okay": 29,
    "poor": 13,
    "terrible": 4
  },
  {
    "Day": 7,
    "excellent": 25,
    "good": 30,
    "okay": 28,
    "poor": 13,
    "terrible": 4
  },
  {
    "Day": 8,
    "excellent": 23,
    "good": 34,
    "okay": 26,
    "poor": 12,
    "terrible": 3
  },
  {
    "Day": 9,
    "excellent": 22,
    "good": 36,
    "okay": 27,
    "poor": 12,
    "terrible": 1
  },
  {
    "Day": 10,
    "excellent": 23,
    "good": 33,
    "okay": 28,
    "poor": 14,
    "terrible": 2
  },
  {
    "Day": 11,
    "excellent": 22,
    "good": 36,
    "okay": 26,
    "poor": 13,
    "terrible": 3
  },
  {
    "Day": 12,
    "excellent": 24,
    "good": 38,
    "okay": 25,
    "poor": 11,
    "terrible": 2
        },
  {
    "Day": 13,
    "excellent": 25,
    "good": 39,
    "okay": 23,
    "poor": 10,
    "terrible": 3
        },
  {
    "Day": 14,
    "excellent": 27,
    "good": 38,
    "okay": 23,
    "poor": 11,
    "terrible": 2
        },
  {
    "Day": 15,
    "excellent": 24,
    "good": 32,
    "okay": 22,
    "poor": 10,
    "terrible": 2
        },
  {
    "Day": 16,
    "excellent": 27,
    "good": 32,
    "okay": 20,
    "poor": 10,
    "terrible": 1
        },
  {
    "Day": 17,
    "excellent": 30,
    "good": 39,
    "okay": 21,
    "poor": 9,
    "terrible": 1
        },
  {
    "Day": 18,
    "excellent": 29,
    "good": 43,
    "okay": 19,
    "poor": 8,
    "terrible": 1
        },
  {
    "Day": 19,
    "excellent": 32,
    "good": 42,
    "okay": 18,
    "poor": 8,
    "terrible": 0
  },
  {
    "Day": 20,
    "excellent": 33,
    "good": 41,
    "okay": 19,
    "poor": 7,
    "terrible": 0
  },
  {
    "Day": 21,
    "excellent": 35,
    "good": 39,
    "okay": 17,
    "poor": 8,
    "terrible": 1
  },
  {
    "Day": 22,
    "excellent": 37,
    "good": 41,
    "okay": 16,
    "poor": 6,
    "terrible": 0
  },
  {
    "Day": 23,
    "excellent": 39,
    "good": 39,
    "okay": 16,
    "poor": 6,
    "terrible": 0
  },
  {
    "Day": 24,
    "excellent": 38,
    "good": 42,
    "okay": 15,
    "poor": 5,
    "terrible": 0
  },
  {
    "Day": 25,
    "excellent": 41,
    "good": 41,
    "okay": 13,
    "poor": 5,
    "terrible": 0
  },
  {
    "Day": 26,
    "excellent": 43,
    "good": 41,
    "okay": 12,
    "poor": 4,
    "terrible": 0
  },
  {
    "Day": 27,
    "excellent": 45,
    "good": 41,
    "okay": 10,
    "poor": 4,
    "terrible": 0
  },
  {
    "Day": 28,
    "excellent": 45,
    "good": 43,
    "okay": 10,
    "poor": 3,
    "terrible": 0
  },
  {
    "Day": 29,
    "excellent": 44,
    "good": 43,
    "okay": 10,
    "poor": 3,
    "terrible": 0
  },
  {
    "Day": 30,
    "excellent": 45,
    "good": 44,
    "okay": 9,
    "poor": 2,
    "terrible": 0
  }
];
