(function () {
    'use strict';
    angular.module('productModule')
    .controller('productSearchController', productSearchController);

  productSearchController.$inject = ['$scope', 'productService'];

  function productSearchController($scope, productService) {
   $scope.categories = [
        {"categoryID" : 1, "categoryName" : "Condiments",
        "description" : "Sauces, relishes, spreads, and seasonings"},
        {"categoryID" : 2, "categoryName" : "Dairy Products",
        "description" : "Cheeses"},
        {"categoryID" : 3, "categoryName" : "Beverages",
        "description" : "Soft drinks, coffees, teas, beers, and ales"},
       
    ];
 
    productService.getAllProducts().then(function(response){
         $scope.products = response.data;
     });
     



  }
  
})();