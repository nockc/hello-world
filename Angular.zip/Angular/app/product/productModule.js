(function () {
  'use strict';
   angular.module('productModule', ['sharedModule']);
})();


