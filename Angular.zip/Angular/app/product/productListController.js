(function () {
    'use strict';
    angular.module('productModule')
    .controller('productListController', productListController);

  productListController.$inject = ['$scope', 'categoryService','productService'];
   
 function productListController($scope, categoryService, productService) {
     
      categoryService.getAllCategories().then(function(response){
         $scope.categories = response.data;
     });      
     productService.getAllProducts().then(function(response){
         $scope.products = response.data;
     });


  }
  
})();