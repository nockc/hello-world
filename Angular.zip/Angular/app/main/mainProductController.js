(function () {
  angular.module("mainModule")
    .controller("mainProductController", mainProductController);

  mainProductController.$inject = ['$scope', 'productService'];

  function mainProductController($scope, productService) {
      
    $scope.topProducts = productService.getFeaturedProducts().then(function(response){
         $scope.products = response.data;
     });
  }
    
})();