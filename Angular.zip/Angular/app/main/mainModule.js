(function () {
  var mod = angular.module("mainModule", ['sharedModule']);  
})();