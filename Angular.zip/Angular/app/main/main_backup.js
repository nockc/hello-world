(function () {
  var mod = angular.module("mainModule", []);
  mod.controller("aboutUsController", function ($scope) {
    $scope.company = {
      name: "Northwind Traders, Inc.",
      street: "2727 North Wind Trail",
      city: "Anytown",
      region: "US",
      postalCode: "99001",
      phone: "867-5309"
    }
    $scope.today1 = new Date();
  })
  mod.controller("mainProductController", function ($scope) {
    console.log("bleeeeeeeh");
	var products = [
	{
		"productID" : 56,
		"productName" : "A fake product",
		"supplierID" : 8,
		"categoryID" : 1,
		"quantityPerUnit" : "Box of 12",
		"unitPrice" : 81,
		"unitsInStock" : 40,
		"unitsOnOrder" : 0,
		"reorderLevel" : 0,
		"discontinued" : 0,
		"featured" : true
	},
	{
		"productID" : 12,
		"productName" : "Another fake product",
		"supplierID" : 8,
		"categoryID" : 3,
		"quantityPerUnit" : "Box of 12",
		"unitPrice" : 11.23,
		"unitsInStock" : 40,
		"unitsOnOrder" : 0,
		"reorderLevel" : 0,
		"discontinued" : 0,
		"featured" : true
	},
	{
		"productID" : 20,
		"productName" : "Yet another fake product",
		"supplierID" : 8,
		"categoryID" : 2,
		"quantityPerUnit" : "6 pack",
		"unitPrice" : 85.44,
		"unitsInStock" : 40,
		"unitsOnOrder" : 0,
		"reorderLevel" : 0,
		"discontinued" : 0,
		"featured" : true
	},
	{
		"productID" : 25,
		"productName" : "A fourth fake product",
		"supplierID" : 8,
		"categoryID" : 4,
		"quantityPerUnit" : "Box of 12",
		"unitPrice" : 81.34,
		"unitsInStock" : 40,
		"unitsOnOrder" : 0,
		"reorderLevel" : 0,
		"discontinued" : 0,
		"featured" : true
	}];
	$scope.topProducts = products;
	$scope.something = "bleh";
	
  })
})();