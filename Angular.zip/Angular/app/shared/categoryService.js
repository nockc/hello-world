(function () {
    'use strict';    
    angular.module('sharedModule')
        .service("categoryService", categoryService)
    
    function categoryService($http){            
        this.getAllCategories = function(){
                var promise = $http({url:'/api/category'});
                return promise;             
                
              };
    }
})();