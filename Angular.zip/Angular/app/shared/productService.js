(function () {
    'use strict';    
    angular.module('sharedModule')
        .service("productService", productService)  
    
    function productService($http){         
        
            this.getAllProducts = function(){
                var promise = $http({url:'/api/product'});
                return promise;             
                
              };
        
        this.getFeaturedProducts = function(){
            var promise = $http({url:'/api/product/featured'});
                return promise; 
        };
        
        this.getProduct = function(productID){
         console.log("getting product with id ", productID);
         return $scope.products.splice($scope.products.findIndex(p => p.product.productID === product.productID), 1);      
            
        };
    }
})();