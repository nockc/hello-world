(function () {
    'use strict';
    angular.module('authModule')
    .controller('loginController', loginController);

  loginController.$inject = ['$scope'];

  function loginController($scope) {
    
    $scope.login = function(user) {
      $scope.successMessage = "You are now logged in as " + user.username;
        $scope.issuccessMessage = true;
    };
    
  };
  
})();