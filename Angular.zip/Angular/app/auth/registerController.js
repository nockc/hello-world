(function () {
    'use strict';
    angular.module('authModule')
    .controller('registerController', registerController);

  registerController.$inject = ['$scope'];

  function registerController($scope) {
    $scope.register = function(user){
       $scope.successMessage = "You have registered " + user.username;
       $scope.issuccessMessage = true;
    }


  };

  
})();